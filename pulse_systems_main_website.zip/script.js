document.getElementById("year").textContent = new Date().getFullYear();

const menuToggle = document.getElementById("menuToggle");
const nav = document.getElementById("mainNav");
menuToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(open));
  menuToggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuToggle.setAttribute("aria-expanded", "false");
}));

document.getElementById("loginButton").addEventListener("click", () => {
  document.getElementById("loginNotice").textContent =
    "Discord login is not configured yet. To enable it safely, add a backend for Discord OAuth2 and connect it to the bot's settings database. Never put your bot token or OAuth client secret in this website's JavaScript.";
});
